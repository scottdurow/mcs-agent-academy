---
name: interview-prep-document
description: >-
  Generate an interview-preparation Word document (.docx) with a code-defined layout for a Job
  Application. Use when asked for an interview prep pack, interview questions document,
  or candidate briefing for a given ApplicationNumber (A#####). Gathers candidate,
  resume, role, and weighted evaluation criteria from Dataverse, then runs a bundled
  Python script to apply fixed sections, ordering, and styles.
---

# interview-prep-document

Produce an interview-preparation Word document for a specific Job Application. The document
is built by **Python** (`generate_interview_doc.py`, using `python-docx`) so its sections,
ordering, and styles come from code. The model prepares the grounded content, so summaries,
evidence wording, and questions can vary between runs.

## When this skill is activated

1. Determine the **ApplicationNumber** (format `A#####`). If it was not provided, ask the user
   for it, or offer to look it up from a candidate/resume.

1. Gather the data with the **Dataverse MCP server** (read-only):
   - The Job Application row (`ppa_jobapplication`) for that ApplicationNumber, and its linked
     **Candidate** (`ppa_candidate`), **Resume** (`ppa_resume`), and **Job Role** (`ppa_jobrole`).
   - The Job Role's related **Evaluation Criteria** (`ppa_evaluationcriteria`, related by
     `ppa_jobrole`) including each criterion's `ppa_weighting`.

1. Prepare the content **grounded only in the data above**:
   - A one-paragraph recruiter summary from the resume summary/cover letter.
   - For each evaluation criterion, the evidence level (Strong / Moderate / Weak / Missing) and a
     short evidence phrase taken from the resume.
   - Exactly 10 interview questions distributed across the criteria (weight the count toward the
     highest-weighted criteria), each mapped to the criterion it tests. Do not ask about protected
     characteristics (age, gender, race, religion, family status, disability, salary history).

1. Write the prepared content to a JSON file named `interview_input.json` using the shape
   documented at the top of `generate_interview_doc.py`.

1. Run the bundled script to build the document:

   ```bash
   python generate_interview_doc.py interview_input.json interview_prep.docx
   ```

1. Return **`interview_prep.docx`** to the user as a downloadable file, and confirm the
   ApplicationNumber, Candidate, and Role it was generated for.

## Guidelines

- The document content must be grounded only in the retrieved Dataverse records - never invent
  experience, criteria, or identifiers.
- Keep questions job-relevant. Omit any protected-characteristic topics.
- If `python-docx` cannot be imported, report the missing runtime dependency and stop. Do not attempt
  a network install from the code-interpreter sandbox.
- If the ApplicationNumber cannot be found, say so clearly and stop; do not fabricate a document.

## Notes

- The Python renderer applies the same layout rules to every `interview_input.json`. The generated
  date reflects the run day, and the agent-prepared JSON content can vary between runs.
- Identifiers: Application = A#####, Candidate = C#####, Resume = R#####, Job Role = J#####.
