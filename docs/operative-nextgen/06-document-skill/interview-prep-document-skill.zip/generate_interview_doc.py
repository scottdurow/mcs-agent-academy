#!/usr/bin/env python3
"""Generate an interview-prep Word document with a code-defined layout.

This script is bundled inside the `interview-prep-document` skill. The agent gathers
the application data from Dataverse (via the Dataverse MCP server), writes it to a JSON
file, then runs:

    python generate_interview_doc.py <input.json> <output.docx>

The script applies the same sections, ordering, and styles to structured input. The
generated date reflects the run day, and a model may have prepared the input content,
but no generative model formats the Word file itself.

Input JSON shape (all fields optional except application_number and candidate.name):

{
  "application_number": "A01000",
  "candidate": { "name": "Avery Example", "email": "avery.example@example.com",
                 "current_title": "Lead Power Platform Engineer", "location": "Remote" },
  "role": { "number": "J1000", "title": "Power Automate Specialist",
            "description": "..." },
  "summary": "One-paragraph recruiter summary...",
  "criteria": [ { "name": "Workflow Automation", "weighting": 35,
                  "evidence": "Built HR intake automation ...", "level": "Strong" } ],
  "questions": [ { "criterion": "Workflow Automation", "weighting": 35,
                   "question": "Describe a complex flow you built ...",
                   "maps_to": "Must-have: automation depth" } ]
}
"""
import json
import sys
from datetime import datetime, timezone

try:
    from docx import Document
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
except ImportError:  # pragma: no cover - guidance if python-docx is unavailable
    sys.stderr.write(
        "python-docx is required. Install it with: pip install python-docx\n"
    )
    raise


def _heading(doc, text, size=16, color=(0x1F, 0x36, 0x60)):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = True
    run.font.size = Pt(size)
    run.font.color.rgb = RGBColor(*color)
    return p


def build(data: dict) -> Document:
    doc = Document()

    # Title block
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    trun = title.add_run("Interview Preparation Pack")
    trun.bold = True
    trun.font.size = Pt(22)

    role = data.get("role", {}) or {}
    cand = data.get("candidate", {}) or {}
    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    srun = sub.add_run(
        f"{cand.get('name', 'Candidate')}  ·  {role.get('title', 'Role')}"
    )
    srun.italic = True
    srun.font.size = Pt(12)

    meta = doc.add_paragraph()
    meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    generated = datetime.now(timezone.utc).strftime("%b %d, %Y")
    meta.add_run(
        f"Application {data.get('application_number', 'N/A')}  ·  "
        f"Generated {generated}"
    ).font.size = Pt(9)

    # Candidate
    _heading(doc, "Candidate")
    for label, key in (("Name", "name"), ("Current title", "current_title"),
                       ("Email", "email"), ("Location", "location")):
        if cand.get(key):
            p = doc.add_paragraph(style="List Bullet")
            r = p.add_run(f"{label}: ")
            r.bold = True
            p.add_run(str(cand[key]))

    # Role
    _heading(doc, "Role")
    rp = doc.add_paragraph(style="List Bullet")
    rp.add_run("Job Role: ").bold = True
    rp.add_run(f"{role.get('number', '')} {role.get('title', '')}".strip())
    if role.get("description"):
        dp = doc.add_paragraph(style="List Bullet")
        dp.add_run("Description: ").bold = True
        dp.add_run(str(role["description"]))

    # Recruiter summary
    if data.get("summary"):
        _heading(doc, "Summary")
        doc.add_paragraph(str(data["summary"]))

    # Evaluation criteria table
    criteria = data.get("criteria") or []
    if criteria:
        _heading(doc, "Evaluation Criteria & Evidence")
        table = doc.add_table(rows=1, cols=4)
        table.style = "Light Grid Accent 1"
        hdr = table.rows[0].cells
        for i, h in enumerate(("Criterion", "Weight", "Evidence level", "Evidence")):
            hdr[i].paragraphs[0].add_run(h).bold = True
        for c in criteria:
            row = table.add_row().cells
            row[0].text = str(c.get("name", ""))
            w = c.get("weighting", "")
            row[1].text = f"{w}%" if w != "" else ""
            row[2].text = str(c.get("level", ""))
            row[3].text = str(c.get("evidence", ""))

    # Interview questions grouped by criterion
    questions = data.get("questions") or []
    if questions:
        _heading(doc, "Interview Questions")
        current = object()
        for q in questions:
            crit = q.get("criterion")
            if crit != current:
                current = crit
                w = q.get("weighting")
                label = crit if crit else "General"
                if w not in (None, ""):
                    label = f"{label} ({w}%)"
                hp = doc.add_paragraph()
                hp.add_run(label).bold = True
            qp = doc.add_paragraph(style="List Number")
            qp.add_run(str(q.get("question", "")))
            if q.get("maps_to"):
                mp = doc.add_paragraph()
                mr = mp.add_run(f"    Maps to: {q['maps_to']}")
                mr.italic = True
                mr.font.size = Pt(9)

    footer = doc.add_paragraph()
    fr = footer.add_run(
        "AI-assisted preparation aid. Review for fairness and job-relevance before use. "
        "Do not ask about protected characteristics."
    )
    fr.italic = True
    fr.font.size = Pt(8)
    return doc


def main(argv):
    if len(argv) < 3:
        sys.stderr.write(
            "Usage: python generate_interview_doc.py <input.json> <output.docx>\n"
        )
        return 2
    with open(argv[1], "r", encoding="utf-8") as fh:
        data = json.load(fh)
    doc = build(data)
    doc.save(argv[2])
    print(f"Wrote {argv[2]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
